-- posix.lua
-- support code for posix library
-- usage lua -lposix ...

module("posix")

require "lposix"

return posix
