--- config.h.old	Sat Jan 31 22:17:25 2004
+++ config.h	Sat Jan 31 22:17:38 2004
@@ -380,4 +380,6 @@
 */
 #define MIN_WOULDBLOCK_DELAY 100L
 
+#define USE_SENDFILE
+
 #endif /* _CONFIG_H_ */
